import UIKit
import CryptoKit

func getData(urlRequest: String) {
    let urlRequest = URL(string: urlRequest)
    guard let url = urlRequest else { return }
    URLSession.shared.dataTask(with: url) { data, response, error in
        if error != nil {
            print("DEBUG: \(String(describing: error?.localizedDescription))")
        } else if let response = response as? HTTPURLResponse, response.statusCode == 200 {
            print("DEBUG: response status code = \(response.statusCode)")
            guard let data = data else { return }
            let dataAsString = String(data: data, encoding: .utf8)
            print(dataAsString ?? "data is nil")
        }
    }.resume()
}
func MD5(string: String) -> String {
    let digest = Insecure.MD5.hash(data: Data(string.utf8))

    return digest.map {
        String(format: "%02hhx", $0)
    }.joined()
}

let publicKey = "c30d4bbd347dda376cdc225f3848096d"
let privateKey = "6f6895231ac1f1e679e98eb95c64ec28987f0a10"

let ts =  "1"
let hash = MD5(string: ts + privateKey + publicKey)
let urlMarvel = "https://gateway.marvel.com/v1/public/creators/6919?ts=" + ts + "&apikey=" + publicKey + "&hash=" + hash

getData(urlRequest: urlMarvel)


